package Solutioniplteams;

import java.util.ArrayList;

public class Teams {
   
	static double avgpoint = 0;
    static int count = 0;
	
	private String name ;
	
	private int points ;
	
	private char[] result ;

	public Teams() {
		
	}

	public Teams(String name, int points, char[] result) {
		super();
		this.name = name;
		this.points = points;
		this.result = result;
	}

	public String getName() {
		return name;
	}

	public int getPoints() {
		return points;
	}

	public char[] getResult() {
		return result;
	}

	@Override
	public String toString() {
		return "Teams [name=" + name + ", points=" + points + ", result=" + result + "]";
	}
    	
	public static ArrayList<String> gettwolosses(ArrayList<Teams> x, int num, String ip)
	{    
	   	ArrayList<String> a = new ArrayList<String>();
			String s = "";
	  		for(int i =0; i<num ; i++) {
			s=s+ip ;
			}
						
		for (Teams teams : x) {
	        char [] c = teams.getResult();
		      for(int i = 0; i<teams.getResult().length ; i++) {
				   	 String str = String.valueOf(c);
		          
		   	        if(str.contains(s)) {
		   	            a.add(teams.getName());		   	          
		   	        	break ;
		   	        }
		        }	        	      
		}
		return a;				
	}
	
	
	public static ArrayList<String> getlosses(ArrayList<Teams> x, int num, String ip)
	{    
	   ArrayList<String> b = new ArrayList<String>();
		  String s = "";
	  	for(int i =0; i<num ; i++) {
					s=s+ip ;
		}
						
		for (Teams teams : x) {
			
		     char [] c = teams.getResult();
		     
		        for(int i = 0; i<c.length ; i++)
		        {		        
		   	        String str = String.valueOf(c);
		          
		   	        if(str.contains(s)) {
		   	         	b.add(teams.getName());
		   	            avgpoint = avgpoint +teams.getPoints();
		   	            count++;
		   	        	break ;
		   	        }
		        }	        	      
		}
		return b;				
	}
	
	public static double getavgpoint()
	{
		double d = avgpoint / count ;
				if(d==0) {
					return 0 ;
			
		}
		return d ;
	}	
}
	   

           


