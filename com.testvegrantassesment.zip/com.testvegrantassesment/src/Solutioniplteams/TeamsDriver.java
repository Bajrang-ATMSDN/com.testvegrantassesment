package Solutioniplteams;

import java.util.Scanner ;
import java.util.ArrayList ;
import java.util.Arrays;
import java.util.InputMismatchException;

public class TeamsDriver {
	
	public static void main(String[] args) {
		
     	
	try {	
		Scanner sc = new Scanner (System.in);
     	
        ArrayList <Teams> teams = new ArrayList <Teams> ();
   
        char [] T1 = {'W','W','L','L','W'};      
        teams.add(new Teams ("GT",20, T1 )) ;
        char [] T2 = {'W','L','L','W','W'} ;
        teams.add( new Teams ("LSG",18, T2 ));
        char [] T3 = {'W','L','W','L','L'} ;
        teams.add( new Teams ("RR",16, T3 )) ;
        char [] T4  = {'W','W','L','W','L'} ;
        teams.add(new Teams ("DC",14, T4 ));
        char [] T5 = {'L','W','W','L','L'};
        teams.add( new Teams ("RCB",14, T5 ));
        char [] T6 = {'L','W','W','L','L'};
        teams.add( new Teams ("KKR",12, T6 ));
        char [] T7 = {'L','W','L','W','L'};
        teams.add( new Teams ("PBKS",12, T7 ));
        char [] T8 = {'W','L','L','L','L'};
        teams.add( new Teams ("SRH",12, T8 ));
        char [] T9 = {'L','L','W','L','W'};
        teams.add(new Teams ("CSK",8, T9 ));
        char [] T10 = {'L','W','L','W','W'};
        teams.add(new Teams ("MI",6, T10 ));
        
        
        System.out.println("All the teams added successfully");
        System.out.println();
      
        
        System.out.println("Teams with two consecutive losses");        
        System.out.println();
        
        System.out.println(Teams.gettwolosses(teams, 2, "L"));
        System.out.println();
        
        System.out.println("Enter the number of losses OR wins");
        int numb = sc.nextInt();
        
        System.out.println("Enter win or loss in the format W/L");
        String ss = sc.next().toUpperCase();
        
    
        ArrayList<String> ans = Teams.getlosses(teams, numb, ss);
             
             if(ans.isEmpty()) {
             System.out.println("There is no such team for this result");      	 
         }
                
         System.out.println(ans);   
             
         System.out.println("Enter 'yes' if you want to get average point for selected teams ");
         String st = sc.next();
         
         if(st.equalsIgnoreCase("Yes")) {
            System.out.println(Teams.getavgpoint());
          }
         
	  }
	catch(InputMismatchException e) {
		
		System.out.println("Plese Enter the valid response");
    }
	catch(Exception e) {
	
		System.out.println("Plese Enter the valid response");
	}
   
  }

}